export const mongoConfig = {
  host: 'localhost',
  port: 27017,
  database: 'test-messages',
}
