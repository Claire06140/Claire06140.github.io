import React from 'react'
import Musics from './components/Musics.jsx'

export default function App(){

  return (
    <>
      <Musics />
    </>
  )
}


